package com.unir.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class MySqlMunicipalities {
    private int mun_id;
    private int pro_id;
    private String name;
}
